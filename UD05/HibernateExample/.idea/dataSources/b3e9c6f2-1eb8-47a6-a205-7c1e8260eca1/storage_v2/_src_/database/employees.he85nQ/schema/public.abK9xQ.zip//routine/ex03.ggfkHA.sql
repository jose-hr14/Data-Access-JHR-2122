create function ex03(name character varying) returns SETOF employee
    language plpgsql
as
$$
DECLARE
    employees employee;
BEGIN
    FOR employees IN
        SELECT * FROM employee
        WHERE UPPER(ename) LIKE UPPER(CONCAT(name, '%'))
        LOOP
            RETURN NEXT employees;
        END LOOP;
END;
$$;

alter function ex03(varchar) owner to postgres;

