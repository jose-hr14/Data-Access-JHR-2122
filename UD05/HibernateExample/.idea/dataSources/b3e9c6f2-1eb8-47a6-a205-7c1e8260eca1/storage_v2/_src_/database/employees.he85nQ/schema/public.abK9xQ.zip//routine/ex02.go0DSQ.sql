create function ex02(thedepartment integer) returns SETOF employee
    language plpgsql
as
$$
DECLARE
    employees employee;
BEGIN
    FOR employees IN
        SELECT * FROM employee
        WHERE deptno = thedepartment
        LOOP
            RETURN NEXT employees;
        END LOOP;
END;
$$;

alter function ex02(integer) owner to postgres;

