create function ex01(thejob character varying) returns SETOF employee
    language plpgsql
as
$$
DECLARE
employees employee;
BEGIN
	FOR employees IN
	SELECT empno, ename, job, deptno FROM employee
	WHERE job = thejob
	LOOP
	RETURN NEXT employees;
	END LOOP;
END;
$$;

alter function ex01(varchar) owner to postgres;

